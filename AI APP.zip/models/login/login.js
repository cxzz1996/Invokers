mui.init();
document.getElementById('login').addEventListener('tap',function(){
	//alert('111');
	var usernameInput=document.querySelector('input[name="username"]');
	var passwordInput=document.querySelector('input[name="password"]');
	//获取用户名，密码信息
	var usernameValue=usernameInput.value;
	var passwordValue=passwordInput.value;
	console.info("username:",usernameValue,"password:",passwordValue);
	if(!usernameValue||!passwordValue){
		mui.toast('username or password is null');
		return;
	}
//	if(usernameValue==='admin'&&passwordValue==='123')
//	{
//		console.info("登录成功");
//		mui.openWindow('../main/main.html','main');
//	}else{
//		mui.toast('error');
//		
//	}

mui.ajax({
	url:'https://gdgcinax.api.lncld.net/1.1/login',
	type:'post',
	data:{
		'username':usernameValue,
		'password':passwordValue
	},
	headers:{
		'X-LC-Id':'gdgCiNAx8mB3VTn7t5i1k5vi-gzGzoHsz',
		'X-LC-Key':'qoAwc40k7T2EkcgTG36X964i'
	},
	success:function(resp){
		mui.toast('登录成功');
		localStorage.setItem('sessionToken',resp.sessionToken);
		localStorage.setItem('usernamee',resp.username);
		
		mui.later(function(){
			mui.openWindow('../main/main.html');
		},1500);
		
	},
	error:function(error){
		debugger
	}
});
});
