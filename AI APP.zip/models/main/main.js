


//底部webview main.html，主webview 其他webview webview
//子webview盖在父webview上
mui.init();
//加载API
mui.plusReady(function(){
	//创建四个webview
	var parentWv=plus.webview.currentWebview();
	var pageList=[
	{
		url:'../chat/chat2.html',
		id:'message'
		
	},
	{
		url:'../address-book/address-book.html',
		id:'address-book'
		
	},
	{
		url:'../mine/mine.html',
		id:'mine'
		
	},
	{
		url:'../discover/discover.html',
		id:'discover'
		
	}
	];
	for(var i=0,l=pageList.length;i<l;i++){
		var url=pageList[i].url;
		var id=pageList[i].id;
		console.info(url+"-------"+id);
		if(plus.webview.getWebviewById(id)){
			continue;
		}
		var newWv=plus.webview.create(url,id,{
			//开始创建webview
			bottom:'50px',
			top:'0px',
			popGesture:'none'
		});
		i===0?newWv.show():newWv.hide();
		parentWv.append(newWv);
	}
	//默认页面
	var showWv='message';
	mui('.mui-bar').on('tap','.mui-tab-item',function(e){
		//mui.alert('sss');
		var showWvId=this.dataset.id;
		if(showWv===showWvId)return;
		//隐藏当前正显示Wv
		plus.webview.getWebviewById(showWv).hide();
		//隐藏即将点击的那个Wvs
		console.info(showWvId);
		plus.webview.getWebviewById(showWvId).show();
		//更新当前子页面的id
		showWv=showWvId;
	});
});
