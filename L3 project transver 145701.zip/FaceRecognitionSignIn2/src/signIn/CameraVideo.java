package signIn;

import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.scene.image.ImageView;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.highgui.VideoCapture;


public class CameraVideo implements Runnable{
    public Mat picture;


    public void run(){
        Stage cameraStage = new Stage();
        cameraStage.setTitle("Camera");
        AnchorPane an = new AnchorPane();
        ImageView image = new ImageView();
        an.getChildren().add(image);
        cameraStage.setScene(new Scene(an));
        cameraStage.show();
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
        VideoCapture camera = new VideoCapture();
        Mat frame = new Mat();
        camera.open(0);
        while(true){
            if(camera.isOpened()){
                camera.read(frame);
                System.out.println("Reading...");
                image.setImage(convertImage.convertToImage(frame));
                //picture = frame;
                try{
                    Thread.sleep(1000);
                } catch (Exception e){
                    e.printStackTrace();
                }
            }

        }
    }
}
