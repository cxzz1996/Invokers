package signIn;

import javafx.scene.image.Image;
import org.opencv.core.Mat;
import org.opencv.core.MatOfByte;
import org.opencv.highgui.Highgui;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;

public class convertImage {

    //Convert openCV Matrix to JavaFX image
    public static Image convertToImage(Mat matrix) {
        MatOfByte byteMat = new MatOfByte();
        Highgui.imencode(".png", matrix, byteMat);
        return new Image(new ByteArrayInputStream(byteMat.toArray()));
        /*
        int cols;
        int rows;
        byte[] data;
        byte type;
        cols = matrix.cols();
        rows = matrix.rows();
        int elemSize = (int)matrix.elemSize();
        data = new byte[cols * rows * elemSize];
        matrix.get(0, 0, data);
        label17:
        switch(matrix.channels()) {
            case 1:
                type = 10;
                break;
            case 3:
                type = 5;
                int i = 0;

                while(true) {
                    if (i >= data.length) {
                        break label17;
                    }

                    byte b = data[i];
                    data[i] = data[i + 2];
                    data[i + 2] = b;
                    i += 3;
                }
            default:
                return null;
        }

        Image image2 = new Image()
        Image image2 = new Image(cols, rows, type);
        image2.getRaster().setDataElements(0, 0, cols, rows, data);
        return image2;*/
    }
    public static BufferedImage matToBufferedImage(Mat matrix) {
        int cols;
        int rows;
        byte[] data;
        byte type;
        cols = matrix.cols();
        rows = matrix.rows();
        int elemSize = (int)matrix.elemSize();
        data = new byte[cols * rows * elemSize];
        matrix.get(0, 0, data);
        label17:
        switch(matrix.channels()) {
            case 1:
                type = 10;
                break;
            case 3:
                type = 5;
                int i = 0;

                while(true) {
                    if (i >= data.length) {
                        break label17;
                    }

                    byte b = data[i];
                    data[i] = data[i + 2];
                    data[i + 2] = b;
                    i += 3;
                }
            default:
                return null;
        }

        BufferedImage image2 = new BufferedImage(cols, rows, type);
        image2.getRaster().setDataElements(0, 0, cols, rows, data);
        return image2;
    }
}
