package signIn;

import com.baidu.aip.face.AipFace;
import org.json.JSONObject;
import org.opencv.core.Mat;

import javax.naming.NamingEnumeration;
import javax.swing.*;
import java.awt.*;
import java.util.Date;
import java.util.HashMap;

public class FaceRecognition implements Runnable {

    public Mat frame;
    public AipFace client;
    public String  image;

    FaceRecognition(Mat frame, AipFace client, String image){
        this.frame = frame;
        this.client = client;
        this.image = image;
    }

    public void run(){

    }
}
