package signIn;

import com.baidu.aip.bodyanalysis.BodyAnalysisConsts;
import com.baidu.aip.face.AipFace;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Border;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.json.JSONObject;
import org.opencv.core.*;
import org.opencv.core.Point;
import org.opencv.highgui.Highgui;
import org.opencv.highgui.VideoCapture;
import org.opencv.objdetect.CascadeClassifier;
import sun.awt.windows.ThemeReader;
import sun.misc.BASE64Encoder;

import javax.swing.*;
import java.awt.*;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;

public class Controller {
    //A class to store data.
    public static class Info {

        private final SimpleStringProperty name;
        private final SimpleStringProperty time;

        private Info(String name, String time) {
            this.name = new SimpleStringProperty(name);
            this.time = new SimpleStringProperty(time);
        }

        public String getName() {
            return name.get();
        }

        public void setName(String oName) {
            name.set(oName);
        }

        public String getTime() {
            return time.get();
        }

        public void setEmail(String oEmail) {
            time.set(oEmail);
        }
    }
    //App information for Baidu face recognition API. All information is just for testing usage. Please apply a new app and change the following three authentication strings.
    public static final String APP_ID = "16288614";
    public static final String API_KEY = "5UYM2Rhe28YEqxD9ar2c4oNY";
    public static final String SECRET_KEY = "AtOgsjbu1zt0t9aNixYGdU5UdsglWbPL";

    public static final String imageType = "BASE64";
    public static final String groupID = "project";//This group ID is just for testing.

    public static final SimpleDateFormat df = new SimpleDateFormat("MM-dd HH:mm:ss");//Time format.

    private List<String> signedStudents = null;//A list used to save signed all students' names.
    private HashMap<String, String> signedMap = null; //A map used to find if the student has signed in. And sign-in time will be stored here.
    private HashMap<String, String> idMap = null;//A map used to store id number and student name.
    private JFrame myFrame;
    private JLabel myLabel;
    private JLabel textLabel;

    public void StartCourse() throws Exception{
        //If the two have not been initialized, initialize them.
        if(signedStudents == null)
            signedStudents = new ArrayList<>();
        if(signedMap == null)
            signedMap = new HashMap<>();
        if(idMap == null)
            idMap = new HashMap<>();
        //Initial AipFace for face recognition.
        AipFace client = new AipFace(APP_ID, API_KEY, SECRET_KEY);
        //Optional: set the timeout option.
        client.setConnectionTimeoutInMillis(5000);
        client.setSocketTimeoutInMillis(120000);

        //Use openCV to detect people and take photos.
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);//Load the openCV library.
        VideoCapture camera = new VideoCapture();
        camera.open(0);//Open the camera.

        if(myFrame == null)
            myFrame = new JFrame();
        myFrame.setBounds(100, 100, 1000, 800);
        myFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        myFrame.setTitle("Face Recognition");
        myFrame.getContentPane().setLayout(null);//Start a new window to show captured pictures.
        if(myLabel == null)
            myLabel = new JLabel("");
        myLabel.setBounds(0, 0, 1000, 500);//A label to show picture.
        if(textLabel == null)
            textLabel = new JLabel("Name");
        textLabel.setText("Recognising");
        textLabel.setFont(new Font("Arial", Font.BOLD, 20));
        textLabel.setBounds(0, 500, 1000, 50);//A label to show information.

        myFrame.getContentPane().add(myLabel);
        myFrame.getContentPane().add(textLabel);
        myFrame.setVisible(true);//Add the two labels to the window and show it.

        textLabel.setText("Detecting faces. Please let the camera see your entire face.");

        if(!camera.isOpened()){//If no camera has been opened, throw an alert.
            //studentStage.close();
            Alert noCameraAlert = new Alert(Alert.AlertType.ERROR);
            noCameraAlert.titleProperty().set("NO CAMERA DETECTED");
            noCameraAlert.headerTextProperty().set("There is no available camera. If you do have a camera, please check if there is another process is using it.");
            noCameraAlert.showAndWait();
        } else {
            System.out.println("Camera open");
            Mat frame = new Mat();//Mat: short for Matrix. An openCV class used to process images. In fact, it is a frame of the video captured.
            while(myFrame.isVisible()){ //Keep detecting when the face recognition window is open.
                camera.read(frame);
                myLabel.setIcon(new ImageIcon(convertImage.matToBufferedImage(frame)));
                textLabel.setText("Detecting faces. Please let the camera see your entire face.");
                textLabel.setForeground(new Color(0,0,0));
                System.out.println("Reading......");
                System.out.println("Image set!");
                CascadeClassifier faceDetector = new CascadeClassifier("libs/haarcascade_frontalface_alt.xml");//Use the model provided by openCV.
                MatOfRect faceDetections = new MatOfRect();
                faceDetector.detectMultiScale(frame, faceDetections);
                Rect[] rectArray = faceDetections.toArray();//Use the trained model to detect faces in the frame. Maybe find 2 or more faces.
                //Faces are marked with an intangible rectangle(including the coordinate of its upper left corner, its height and width)
                //More technical details are not important for us. We just need to know that openCV help us find faces..
                Rect theBigRect = new Rect(0, 0, 0, 0);//Find the biggest face in the frame. In case that small faces are detected and uploaded, leading to recognition failure.
                if(rectArray.length > 0){
                    for(Rect rect : rectArray){
                        if(rect.width * rect.height > theBigRect.height * theBigRect.width){
                            theBigRect = new Rect(rect.x, rect.y, rect.width, rect.height);
                        }
                    }
                    if(theBigRect.height < 100 || theBigRect.width < 100)
                        continue;
                    Mat imageRoi = new Mat(frame, theBigRect);
                    String saveName = "tempPics/" + UUID.randomUUID().toString().replaceAll("-", "") + ".png";//Use uuid to generate a unique file name for image file we are going to save.
                    File testFile = new File("tempPics/test");
                    File dir = testFile.getParentFile();
                    if(!dir.exists())
                        dir.mkdir();//If the directory temPics/ does not exists, make a new directory.
                    Highgui.imwrite(saveName, imageRoi);//Save the image file
                    Core.rectangle(frame, new Point(theBigRect.x, theBigRect.y), new Point(theBigRect.x + theBigRect.width, theBigRect.y + theBigRect.height), new Scalar(0, 0, 255), 2 );//Draw a rectangle to mark face.
                    myLabel.setIcon(new ImageIcon(convertImage.matToBufferedImage(frame)));//Convert the Matrix format image to BufferedImage format and show it.
                    String image = encode(new File(saveName));//Convert the saved image file to BASE64 format.

                    HashMap<String, String> options = new HashMap<String, String>();
                    options.put("max_user_num", "1");//We just need one result.
                    JSONObject res = client.search(image, imageType, groupID, options);
                    System.out.println(res.toString(2));
                    //Following is parsing the JSON result.

                    String error_msg = res.get("error_msg").toString();//If error occurs.
                    if(!error_msg.equals("SUCCESS")){
                        if(error_msg.startsWith("connection or read")){
                            textLabel.setText("Offline. Please check connection and restart the app.");
                            textLabel.setForeground(new Color(255, 99, 71));
                            Thread.sleep(1000);
                            break;
                        } else{
                            textLabel.setText(error_msg);
                            textLabel.setForeground(new Color(255, 99, 71));
                            Thread.sleep(800);
                            continue;
                        }
                    }

                    String result = res.getJSONObject("result").get("user_list").toString();

                    String[] ret = result.replace("[", "").replace("]", "").replace("\"", "").replace("{", "").replace("}", "").split(",");//Find returned information we need.
                    String scores = ret[0];
                    String names = ret[2];
                    String ids = ret[3];//Pick out score, name and user info(ID) strings.
                    String[] score = scores.split(":");//Here is the score string: score:90, which is split by ":".
                    String[] name = names.split(":");//Ditto.
                    String[] id = ids.split(":");//Ditto.
                    //If found a person's image and its similarity to the student taking photo
                    if(Float.parseFloat(score[1]) > 70){ //70 can be changed. Bigger number requires more similar image.
                        //System.out.println(signedMap.toString());
                        if(signedMap.containsKey(id[1]))
                        {
                            textLabel.setText(name[1].replace("_", " ") + ", you have signed in at " + signedMap.get(id[1]) + ". \nPlease sign in just one time");
                            textLabel.setForeground(new java.awt.Color(255, 99, 71));
                            Thread.sleep(800);
                        }else {
                            System.out.println("found a person");
                            signedStudents.add(id[1]);
                            if(!idMap.containsKey(id[1])){
                                idMap.put(id[1], name[1]);
                            }
                            signedMap.put(id[1], df.format(new Date()));
                            textLabel.setText(id[1] + " " + name[1].replace("_", " ") + ", you signed in successfully.");
                            textLabel.setForeground(new java.awt.Color(46, 139, 87));
                            Thread.sleep(800);
                        }
                    } else {
                        textLabel.setText("Person not found");
                        textLabel.setForeground(new Color(255, 99, 71));
                        Thread.sleep(800);
                    }

                    Thread.sleep(200);
                }
                Thread.sleep(100);//Save CPU resource.
            }
            if(!myFrame.isVisible()){
                camera.release();
            }
        }
    }

    public void EndCourse() throws Exception{
        //Create a new file used to save names and sign-in time.
        if(signedStudents == null || signedStudents.isEmpty())
        {
            Alert noStudentAlert = new Alert(Alert.AlertType.ERROR);
            noStudentAlert.titleProperty().set("NO STUDENT HAS SIGNED IN");
            noStudentAlert.headerTextProperty().set("No sign-in record found. Please click start course first.");
            noStudentAlert.showAndWait();
            return;
        }
        File file = new File("NameList" + df.format(new Date()).trim().replace(":", "") + ".xls");
        file.createNewFile();
        FileWriter writer = new FileWriter(file.getName(), true);
        writer.write("ID\tName\tSign in Time\n");//Write the column names.
        //Write each student's name and time.
        for(String id : signedStudents) {
            writer.write(id + "\t" + idMap.get(id).replace("_", " ") + "\t" + signedMap.get(id) + "\n");
            System.out.println("Wrote a record.");
        }
        writer.close();//Close the writer.
        //Clear saved data.
        signedMap.clear();
        signedStudents.clear();
        signedStudents = null;
        signedMap = null;
        Alert saveSuccess = new Alert(Alert.AlertType.INFORMATION);
        saveSuccess.setTitle("SUCCESS");
        saveSuccess.setHeaderText("The list has been saved.");
        saveSuccess.showAndWait();
    }

    //Add students' image into our Baidu face recognition library.
    //!!!IMPORTANT: FILE NAME MUST BE STUDENTS' NAME
    public void ImportStudents() throws Exception{
        //Initial a file chooser (used to choose files).
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Import Students from Images");
        //Set a extension filter (only picture files can be selected). More extension names can be added here.
        fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Pictures", "*.png","*.jpg","*.jpeg"));
        Stage fileChooseStage = new Stage();
        List<File> files = fileChooser.showOpenMultipleDialog(fileChooseStage);//Use file chooser to choose image file.
        if(files==null || files.isEmpty())//If no image selected.
            return;
        for (File pic:files) {
            String[] fileName = pic.getName().replace(" ", "_").split("\\.");
            String user_id = fileName[0];//We take the picture's name as the student's name. Space will be replaced by underscore, and the file extension name will be removed here.
            String[] stuInfo = user_id.split("\\+");
            String image = encode(pic);//Base64 picture.
            HashMap<String, String> options = new HashMap<String, String>();//Options while uploading picture, we don't need it in our app here.
            options.put("user_info", stuInfo[0]);//Add ID numbers.
            //Initial AipFace for face recognition.
            AipFace client = new AipFace(APP_ID, API_KEY, SECRET_KEY);

            //Optional: set the timeout option.
            client.setConnectionTimeoutInMillis(5000);
            client.setSocketTimeoutInMillis(120000);
            //Send information to Baidu and add faces to our face library.
            JSONObject res = client.addUser(image,imageType, groupID, stuInfo[1], options);

            String error_msg = res.get("error_msg").toString();
            if(!error_msg.equals("SUCCESS")){//If error occurs, give information and stop importing.
                Alert failAlert = new Alert(Alert.AlertType.ERROR);
                failAlert.setContentText("FAIL");
                failAlert.setHeaderText(error_msg);
                failAlert.showAndWait();
                return;
            }
            System.out.print(res.toString(2));
            Thread.sleep(500);//We can just use the API 2 times in a second for free, sleep for a while to save money.
        }
        Alert okAlert = new Alert(Alert.AlertType.INFORMATION);
        okAlert.setTitle("SUCCESS");
        okAlert.setHeaderText("Imported successfully");
        okAlert.showAndWait();//Show an alert saying that imports students successfully.
    }

    public void SeeSignIn() throws Exception{
        if(signedStudents != null){//When signedStudents is null, the course hasn't started or has ended.
            //Start a new window to show signed-in students.
            JFrame listFrame = new JFrame("Sign-in List");
            listFrame.setBounds(100, 100, 400, 800);//Set the window's location and size.
            listFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);//Set the close operation. The app will not be closed if the window is closed.

            JPanel jp = new JPanel(new BorderLayout());
            Object[] columns = {"ID", "Name", "Time"};//Column headers.
            String[][] info = new String[signedMap.size()][3];
            int c = 0;
            for (Map.Entry<String, String> entry : signedMap.entrySet()) {
                System.out.println("key = " + entry.getKey() + " and value = " + entry.getValue());
                info[c][0] = entry.getKey();
                info[c][1] = idMap.get(entry.getKey()).replace("_", " ");
                info[c][2] = entry.getValue();
                c++;
            }//Convert the map signedMap to String[][] so that it can be added to the table.
            JTable table = new JTable(info, columns);//Create a table including headers and content.
            jp.add(table.getTableHeader(), BorderLayout.NORTH);
            jp.add(table, BorderLayout.CENTER);//Add the table to the window.
            listFrame.setContentPane(jp);
            listFrame.setVisible(true);//Show the window.

        }else {//When there is no data, show an alert.
            Alert noData = new Alert(Alert.AlertType.ERROR);
            noData.setTitle("NO DATA");
            noData.setHeaderText("No sign-in record found. Please click start course first");
            noData.showAndWait();
            return;
        }
    }

    public void GetStudents(){
        //Initial AipFace for face recognition.
        AipFace client = new AipFace(APP_ID, API_KEY, SECRET_KEY);

        //Optional: set the timeout option.
        client.setConnectionTimeoutInMillis(5000);
        client.setSocketTimeoutInMillis(120000);

        //Optional: set the optional options.
        HashMap<String, String> options = new HashMap<String, String>();
        options.put("start", "0");

        //Use Baidu API to get students who are already exists
        JSONObject res = client.getGroupUsers(groupID, options);

        String error_msg = res.get("error_msg").toString();
        if(!error_msg.equals("SUCCESS")){//If error occurs, give information and stop.
            Alert failAlert = new Alert(Alert.AlertType.ERROR);
            failAlert.setContentText("FAIL");
            failAlert.setHeaderText(error_msg);
            failAlert.showAndWait();
            return;
        }
        //Get useful information from the returned JSON string.
        String nameList = res.getJSONObject("result").get("user_id_list").toString();
        //Convert the JSON string to string[]. Just remove [, ], ", and convert the underscores to spaces.
        String[] names = nameList.replace("[","").replace("]","")
                .replace("\"","").replace("_", " ").split(",");

        //Start a window to see student list.
        Stage studentStage = new Stage();
        studentStage.setTitle("Student List");
        AnchorPane an = new AnchorPane();

        //Put student names to the list view.
        ListView<String> viewList = new ListView<String>();
        ObservableList<String> nameItems = FXCollections.observableArrayList(names);
        viewList.setItems(nameItems);

        an.getChildren().add(viewList);
        Scene scene = new Scene(an);
        studentStage.setScene(scene);
        studentStage.show();//Show the list.
    }
    //Convert a file to BASE64 format.
    private static String encode(File file) throws Exception{
        byte[] buffer = new byte[(int)file.length()];
        FileInputStream input = new FileInputStream(file);
        input.read(buffer);
        input.close();
        return new BASE64Encoder().encode(buffer);
    }

}

